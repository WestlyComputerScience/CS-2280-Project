package edu.iastate.cs2280.hw3;

import java.util.AbstractSequentialList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

import ADT_Practice.DoublyLinked_LIST2.Node;

/**
 * Implementation of the list interface based on linked nodes
 * that store multiple items per node.
 */
public class StoutList<E extends Comparable<? super E>> extends AbstractSequentialList<E>
{
	/**
	 * Default number of elements that may be stored in each node.
	 */
	private static final int DEFAULT_NODESIZE = 4;

	/**
	 * Number of elements that can be stored in each node.
	 */
	private final int nodeSize;

	/**
	 * Dummy node for head
	 */
	public Node head;

	/**
	 * Dummy node for tail.
	 */
	private Node tail;

	/**
	 * Number of elements in the list.
	 */
	private int size;

	/**
	 * Constructs an empty list with the default node size.
	 */
	public StoutList()
	{
		this(DEFAULT_NODESIZE);
	}

	/**
	 * Constructs an empty list with the given node size.
	 * 
	 * @param nodeSize: number of elements that may be stored in each node, must be 
	 *   an even number
	 */
	public StoutList(int nodeSize)
	{
		if (nodeSize <= 0 || nodeSize % 2 != 0) throw new IllegalArgumentException();

		// dummy nodes
		head = new Node();
		tail = new Node();
		head.next = tail;
		tail.previous = head;
		this.nodeSize = nodeSize;
	}

	/**
	 * Constructor for stout list. Used to insert a custom list.
	 * 
	 * @param head: the head of the list
	 * @param tail: the tail of the list
	 * @param nodeSize: the node size of the list
	 * @param size: the size of the list
	 */
	public StoutList(Node head, Node tail, int nodeSize, int size)
	{
		this.head = head; 
		this.tail = tail; 
		this.nodeSize = nodeSize; 
		this.size = size; 
	}
	
	/**
	 * Gets the size of the list.
	 * 
	 * @return returns the size of the list
	 */
	@Override
	public int size()
	{
		return size;
	}
	
	/**
	 * Adds an item to the end of the list.
	 * 
	 * @param item: the item you're inserting into the list
	 * @return returns if the add method was successful
	 */
	@Override
	public boolean add(E item)
	{
		if(item == null)
		{
			throw new NullPointerException("Inserted item is null");
		}
		if(size == 0)
		{
			Node newNode = new Node();
			newNode.previous = head;
			newNode.next = tail;
			head.next = newNode;
			tail.previous = newNode;
			newNode.addItem(item);
		}
		else
		{
			Node beforeTail = tail.previous;
			for(int i = 0; i < nodeSize; i++)
			{
				if(beforeTail.data[i] == null) //if there's room
				{
					beforeTail.addItem(item);
					size++;                   //don't forget this!
					return true;
				}
			}
			Node newNode = new Node();  //if there's no room
			link(tail.previous, newNode); //links node in between the node before tail and tail
			newNode.addItem(item);
		}
		size++;
		return true;
	}
	
	/**
	 * Adds an element at a certain position in the list, shifting
	 * everything over if necessary.
	 * 
	 * @param pos: the position you want to insert the element in
	 * @param item: the item you want to insert
	 */
	@Override
	public void add(int pos, E item)
	{
		if(item == null)
		{
			throw new NullPointerException("Inserted item is null");
		}
		if(pos < 0 || pos > size)
		{
			throw new IndexOutOfBoundsException();
		}
		
		if(size == 0)
		{
			Node newNode = new Node();  //just creates a new Node
			newNode.previous = head;
			newNode.next = tail;
			head.next = newNode;
			tail.previous = newNode;
			newNode.addItem(item);
		}
		else
		{
			NodeInfo nodeToAddTo = findNodeInfo(pos);    //returns node and offset you want to add to
			add(nodeToAddTo.node, nodeToAddTo.offset, item);  //does all the other special cases
		}
		size++;
	}
	
	/**
	 * Returns the Node Information that it added the element to
	 * 
	 * @param n :which node to add to
	 * @param offset: what index in the node you want to add to
	 * @param item: the item to put into the Node
	 * @return returns the information about where it was added
	 */
	private NodeInfo add(Node n, int offset, E item)  //returns node and offset it added to
	{
		if(offset == 0) //if offset 0
		{
			if(n == tail) //if it's the tail
			{
				if(tail.previous.count < nodeSize) //if previous node to tail has space
				{
					tail.previous.addItem(item);
					return new NodeInfo(tail.previous, tail.previous.count - 1);
				}
				else //if previous node to tail full create a new Node
				{
					Node newNode = new Node();
					link(tail.previous, newNode); //Link new Node before tail
					newNode.addItem(item);
					return new NodeInfo(newNode, 0);
				}
			}
			else if(n.previous != head && n.previous.count < nodeSize) //if previous node has space and isn't the head
			{
				n.previous.addItem(item);
				return new NodeInfo(n.previous, n.previous.count - 1);
			}
		}
		
		if(n.data[offset] == null) //if there's open space in node
		{
			n.addItem(item);
			return new NodeInfo(n, offset);
		}
		else //if there's no open space
		{
			if(n.count == nodeSize) //if the node is full, split it up
			{
				Node newNode = new Node(); //creates a new Node
				link(n, newNode);
				int k = 0;
				for(int i = nodeSize / 2; i < nodeSize; i++) //puts it first half of old node elements into the new Node
				{
					newNode.data[k] = n.data[i];
					n.data[i] = null;
					k++;
				}
				n.count = nodeSize/2;  //updates counts
				newNode.count = k;
				if(offset < nodeSize/2) //if the offset isn't greater than half the node size
				{
					n.addItem(offset, item);
					return new NodeInfo(n, offset);
				}
				else //if the offset is greater than half the node size
				{
					newNode.addItem(offset - nodeSize/2, item);
					return new NodeInfo(newNode, offset - nodeSize/2);
				}
			}
			else //if the node has space, shift elements over and add it
			{
				n.addItem(offset, item);
				return new NodeInfo(n, offset);
			}
		}
	}
	
	/**
	 * Removes an element at a given position from the list, 
	 * potentially shifting nodes if necessary.
	 * 
	 * @param pos: the position of the element you want removed
	 * @return returns the element removed
	 */
	@Override
	public E remove(int pos)
	{
		if(size == 0) //if nothing in list to begin with
		{
			throw new IllegalStateException();
		}
		if(pos < 0 || pos >= size) //this time can't include size, must be size - 1
		{
			throw new IndexOutOfBoundsException();
		}
		
		NodeInfo removeNodeInfo = findNodeInfo(pos);  //finds the offset and node
		E info = removeNodeInfo.node.data[removeNodeInfo.offset]; //gets the info of the element you want removed
		Node removeNode = removeNodeInfo.node;   //improves readability
		int offset = removeNodeInfo.offset;      // ^
		
		for(int i = offset; i < nodeSize - 1; i++) //shifts all elements in node back
		{
			removeNode.data[i] = removeNode.data[i + 1];
		}
		removeNode.data[removeNode.count - 1] = null; // A B C - now B C - -
		removeNode.count--;
		
		if(removeNode == tail.previous && removeNode.count == 0) //if it's the last node with only 1 element
		{
			unlink(removeNode); //removes node
		}
		else if(removeNode == tail.previous || removeNode.count > nodeSize/2) //if the node is the last node with more than M/2 elements in it
		{
			//nothing needed, just return removed element
		}
		else  //then do merge
		{
			Node nextNode = removeNode.next;
			if(nextNode.count > nodeSize/2)  //mini-merge part
			{
				removeNode.data[removeNode.count] = nextNode.data[0];  //move next node's first element to remove node
				removeNode.count++;
				for(int i = 0; i < nextNode.count - 1; i++)  //shift all the elements in next node
				{
					nextNode.data[i] = nextNode.data[i + 1];
				}
				nextNode.data[nextNode.count - 1] = null;
				nextNode.count--;
			}
			else //big merge
			{
				for(int i = 0; i < nextNode.count; i++)  //shifts all elements into remove node
				{
					removeNode.data[removeNode.count + i] = nextNode.data[i];
				}
				removeNode.count = removeNode.count + nextNode.count;  //deletes next node
				unlink(nextNode);
			}
		}
		
		if(size == 1) //if it was the last node
		{
			head.next = tail;
			tail.previous = head;
		}
		
		size--;
		return info;
	}

	/**
	 * Sorts all elements in the stout list in the non-decreasing order using insertion sort.
	 */
	public void sort()
	{
		E[] arr = (E[]) new Comparable[size];
		Node cursor = head.next;
		int indexArr = 0;        //used to keep the count of the array, not just the node index
		while(cursor != tail)
		{
			int index = 0;
			while(index < cursor.count)
			{
				arr[indexArr] = cursor.data[index];  //adds element to array, deletes it from cursor
				cursor.data[index] = null;
				index++;
				indexArr++;
			}
			Node temp = cursor.next;
			cursor.previous.next = cursor.next;  //gets rid of node
			cursor.next.previous = cursor.previous;
			cursor = temp;
		}
		
		Comparator<E> nonDecreasingOrder = new Comparator<E>()  //creates a compare method
				{
					@Override
					public int compare(E o1, E o2)
					{
						return o1.compareTo(o2);
					}
				};
		
		insertionSort(arr, nonDecreasingOrder);
		
		head.next = tail;  //reset list
		tail.previous = head;
		size = 0;
		
		for(E element: arr)  //copy sorted arr back into the list
		{
			add(element);
		}
	}

	/**
	 * Sorts all elements in the stout list in the non-increasing order using bubbleSort().
	 */
	public void sortReverse() 
	{
		E[] arr = (E[]) new Comparable[size];
		Node cursor = head.next;
		int indexArr = 0;        //used to keep the count of the array, not just the node index
		while(cursor != tail)
		{
			int index = 0;
			while(index < cursor.count)
			{
				arr[indexArr] = cursor.data[index];  //adds element to array, deletes it from cursor
				cursor.data[index] = null;
				index++;
				indexArr++;
			}
			Node temp = cursor.next;
			cursor.previous.next = cursor.next;  //gets rid of node
			cursor.next.previous = cursor.previous;
			cursor = temp;
		}
		
		bubbleSort(arr);
		
		head.next = tail;  //reset list
		tail.previous = head;
		size = 0;
		
		for(E element: arr)  //copy sorted array back into the list
		{
			add(element);
		}
	}
	
	/**
	 * Returns a standard iterator that iterates through the loop.
	 * 
	 * @return returns the basic iterator
	 */
	@Override
	public Iterator<E> iterator()
	{
		return new StoutIterator();
	}
	
	/**
	 * A private iterator class used to test if basic methods work
	 */
	private class StoutIterator implements Iterator<E>
	{
		/**
		 * The node that the list points to 
		 */
		private Node cursor;
		
		/**
		 * The index in the node array it points to
		 */
		private int nodeIndex;
		
		/**
		 * Default constructor for the iterator.
		 */
		public StoutIterator()
		{
			cursor = head.next;
			nodeIndex = 0;
		}
		
		/**
		 * Returns if the list has a next element, either goes to
		 * the next node or next element in the array.
		 * 
		 * @return returns a true or false based on the list having a next element
		 */
		@Override
		public boolean hasNext() 
		{
			if(cursor == tail)
			{
				return false;
			}
			
			if (nodeIndex < nodeSize && cursor.data[nodeIndex] != null) //checks if there's a next element in the node array
			{
		        return true;
		    }
			
			Node checkAfterCursor = cursor.next;
		    while (checkAfterCursor != tail)      //loops until no more nodes
		    {
		        for (int i = 0; i < nodeSize; i++)        //loops in the array in nodes
		        {
		            if (checkAfterCursor.data[i] != null) 
		            {
		                return true;
		            }
		        }
		        checkAfterCursor = checkAfterCursor.next;
		    }
		    return false;
		}
		
		/**
		 * Used to get the next element in a list, either getting
		 * an element from the next node or next element in the array.
		 * 
		 * @return returns if the list has a next element true or false.
		 */
		@Override
		public E next() 
		{
			if(!hasNext())
			{
				throw new NoSuchElementException();
			}
			
			while(cursor != tail)      //loops through all nodes
			{
				while(nodeIndex < nodeSize)      //loops through node array
				{
					if(cursor.data[nodeIndex] != null)  //if it finds an element
					{
						E info = cursor.data[nodeIndex];
						nodeIndex++;
						return info;
					}
					nodeIndex++;
				}
				nodeIndex = 0;        //resets node index
				cursor = cursor.next;
			}
			System.out.println("Next method in StoutIterator didn't work");
			return null; //shouldn't happen, just in case it fails
		}
		
		/*
		 * Not implemented for this Iterator!
		 */
		@Override
		public void remove()
		{
			throw new UnsupportedOperationException();
		}
	}
	
	/**
	 * Creates a more advanced iterator. It includes previous method, indices, etc.
	 * This is the default constructor for it.
	 * 
	 * @return returns the more advanced iterator
	 */
	@Override
	public ListIterator<E> listIterator()
	{
		return new StoutListIterator();
	}
	
	/**
	 *  Creates a more advanced iterator. It includes previous method, indices, etc.
	 *  
	 *  @param index: the position you want it to start at
	 *  @return returns the more advanced iterator
	 */
	@Override
	public ListIterator<E> listIterator(int index)
	{
		return new StoutListIterator(index);
	}

	/**
	 * Returns a string representation of this list showing
	 * the internal structure of the nodes.
	 * 
	 * @return returns the string
	 */
	public String toStringInternal()
	{
		return toStringInternal(null);
	}

	/**
	 * Returns a string representation of this list showing the internal
	 * structure of the nodes and the position of the iterator.
	 *
	 * @param iter: an iterator for this list
	 */
	public String toStringInternal(ListIterator<E> iter) 
	{
		int count = 0;
		int position = -1;
		if (iter != null) 
		{
			position = iter.nextIndex();
		}

		StringBuilder sb = new StringBuilder();
		sb.append('[');
		Node current = head.next;
		while (current != tail) 
		{
			sb.append('(');
			E data = current.data[0];
			if (data == null) 
			{
				sb.append("-");
			} 
			else 
			{
				if (position == count) 
				{
					sb.append("| ");
					position = -1;
				}
				sb.append(data.toString());
				++count;
			}

			for (int i = 1; i < nodeSize; ++i) 
			{
				sb.append(", ");
				data = current.data[i];
				if (data == null) {
					sb.append("-");
				} 
				else 
				{
					if (position == count) 
					{
						sb.append("| ");
						position = -1;
					}
					sb.append(data.toString());
					++count;

					// iterator at end
					if (position == size && count == size) 
					{
						sb.append(" |");
						position = -1;
					}
				}
			}
			sb.append(')');
			current = current.next;
			if (current != tail)
				sb.append(", ");
		}
		sb.append("]");
		return sb.toString();
	}


	/**
	 * Node type for this list.  Each node holds a maximum
	 * of nodeSize elements in an array.  Empty slots
	 * are null.
	 */
	private class Node
	{
		/**
		 * Array of actual data elements.
		 */
		public E[] data = (E[]) new Comparable[nodeSize];

		/**
		 * Link to next node.
		 */
		public Node next;

		/**
		 * Link to previous node;
		 */
		public Node previous;

		/**
		 * Index of the next available offset in this node, also 
		 * equal to the number of elements in this node.
		 */
		public int count;

		/**
		 * Adds an item to this node at the first available offset.
		 * 
		 * Precondition: count < nodeSize
		 * @param item element to be added
		 */
		void addItem(E item)
		{
			if (count >= nodeSize)
			{
				return;
			}
			data[count++] = item;
		}

		/**
		 * Adds an item to this node at the indicated offset, shifting
		 * elements to the right as necessary.
		 * 
		 * Precondition: count < nodeSize
		 * @param offset array index at which to put the new element
		 * @param item element to be added
		 */
		void addItem(int offset, E item)
		{
			if (count >= nodeSize)
			{
				return;
			}
			for (int i = count - 1; i >= offset; --i)
			{
				data[i + 1] = data[i];
			}
			++count;
			data[offset] = item;
		}

		/**
		 * Deletes an element from this node at the indicated offset, 
		 * shifting elements left as necessary.
		 * 
		 * Precondition: 0 <= offset < count
		 * @param offset: the offset you want to delete from
		 */
		void removeItem(int offset)
		{
			E item = data[offset];
			for (int i = offset + 1; i < nodeSize; ++i)
			{
				data[i - 1] = data[i];
			}
			data[count - 1] = null;
			--count;
		}
	}
	
	/**
	 * This creates an object that stores information about a node and the offset it's pointing to
	 */
	private class NodeInfo
	{
		/**
		 * The node it's referring to
		 */
		public Node node;
		
		/**
		 * The offset for the node
		 */
		public int offset;
		
		/**
		 * Constructor for the NodeInfo class. Creates a 
		 * NodeInfo object that stores the node and offset.
		 * 
		 * @param node: the node it's referring to
		 * @param offset: the offset it's referring to
		 */
		public NodeInfo(Node node, int offset)
		{
			this.node = node;
			this.offset = offset;
		}
	}
	
	/**
	 * Returns the node and offset for the given logical index.
	 * 
	 * @param pos: the position of the node and index you want to find
	 */
	private NodeInfo findNodeInfo(int pos)
	{
	    if (pos < 0 || pos > size)
	    {
	        throw new IndexOutOfBoundsException();
	    }
	    
	    if (pos == size) //if it equals size it returns the last node before the tail and its available offset
	    {
	    	Node beforeTail = tail.previous;
	    	if(beforeTail.count < nodeSize)   //if node previous to tail not full
	    	{
	    		return new NodeInfo(beforeTail, beforeTail.count);
	    	}
	    	else  //if the previous node is full and needs to have cursor at end
	    	{
	    		return new NodeInfo(tail, 0);
	    	}
	    }
	    
	    Node current = head.next;
	    int i = 0;
	    while (current != tail)
	    {
	        if (i + current.count > pos)       //if it's within a certain offset
	        {
	            int offset = pos - i;                    //gets the offset, like position 17 - 14 = 3
	            NodeInfo n = new NodeInfo(current, offset);
	            return n;    //returns Node info on the node and it's offset
	        }
	        i += current.count;             //adds up the offsets
	        current = current.next;        //goes to next Node
	    }
	    
	    System.out.println("findNodeInfo didn't work");
	    return null; // Shouldn't happen if pos is within bounds
	}

	private class StoutListIterator implements ListIterator<E>
	{
		/**
		 * The node the iterator points to.
		 */
		private Node cursor;
		
		/**
		 * The position the iterator points to.
		 */
		private int position;
		
		/**
		 * The index in the node the iterator points to.
		 */
		private int nodeIndex;
		
		/**
		 * The direction of the iterator.
		 */
		private int direction;
		
		/**
		 * AHEAD is used when previous is called (used by direction).
		 */
		private static final int AHEAD = 1;  //previous()
		
		/**
		 * NONE is used when you need a call to next() or previous for certain methods to work.
		 */
		private static final int NONE = 0;
		
		/**
		 * BEHIND is used when next is called (used by direction).
		 */
		private static final int BEHIND = -1;  //next()
		
		/**
		 * Default constructor for the advanced iterator.
		 */
		public StoutListIterator()
		{
			this(0);
		}

		/**
		 * Constructor finds node at a given position for the advanced iterator.
		 * 
		 * @param pos: the position you want the iterator at
		 */
		public StoutListIterator(int pos)
		{
			 //System.out.println("pos: " + pos + ", size: " + size); // Debugging print statement
			if(pos < 0 || pos > size)
			{
				throw new IndexOutOfBoundsException();
			}
			
			if(size == 0)
			{
				cursor = head.next; //which points to tail
				nodeIndex = 0;
				position = 0;
				direction = NONE;
			}
			else
			{
				NodeInfo n = findNodeInfo(pos); //gets the offset and Node
				cursor = n.node;
				position = pos;
				nodeIndex = n.offset;
				direction = NONE;
			}
		}
		
		/**
		 * Returns if the list has a next element, either goes to
		 * the next node or next element in the array.
		 * 
		 * @return returns a true or false based on the list having a next element
		 */
		@Override
		public boolean hasNext()
		{
			if(size == 0)
			{
				return false;
			}
			
			if(cursor == tail)
			{
				return false;
			}
			
			if (nodeIndex < nodeSize && cursor.data[nodeIndex] != null) //checks if there's a next element in the node array
			{
		        return true;
		    }
			
			Node checkAfterCursor = cursor.next;
		    while (checkAfterCursor != tail)      //loops until no more nodes
		    {
		        for (int i = 0; i < nodeSize; i++)        //loops in the array in nodes
		        {
		            if (checkAfterCursor.data[i] != null) 
		            {
		                return true;
		            }
		        }
		        checkAfterCursor = checkAfterCursor.next;
		    }
		    return false;
		}
		
		/**
		 * Used to get the next element in a list, either getting
		 * an element from the next node or next element in the array.
		 * 
		 * @return returns if the list has a next element true or false.
		 */
		@Override
		public E next()
		{	
			if(!hasNext())
			{
				throw new NoSuchElementException();
			}

			while(cursor != tail)      //loops through all nodes
			{
				while(nodeIndex < nodeSize)      //loops through node array
				{
					if(cursor.data[nodeIndex] != null)  //if it finds an element
					{
						E info = cursor.data[nodeIndex];
						nodeIndex++;
						position++;
						direction = BEHIND;
						return info;
					}
					nodeIndex++;
				}
				nodeIndex = 0;        //resets node index
				cursor = cursor.next;
			}
			System.out.println("Next method in StoutListIterator didn't work");
			return null; //shouldn't happen, just in case it fails
		}
		
		/**
		 * Removes an element to the left of the cursor.
		 */
		@Override
		public void remove()
		{
			Node currentNode = null; //used for later
			int currentIndex = -1; //used for later
			
			if(direction == NONE)
			{
				throw new IllegalStateException();
			}
			else if(direction == AHEAD) //previous(), grabs cursor
			{
				if(size == 1) //if there's only 1 element in one Node
				{
					removeOnlyOneElement(); //helper method for this case
					return;
				}
				else //just grabs the element
				{
					currentNode = cursor;
					currentIndex = nodeIndex;
				}
			}
			else if(direction == BEHIND) //next(), grabs before cursor
			{
				if(size == 1) //if there's only 1 element in one Node
				{
					removeOnlyOneElement(); //helper method for this case
					return;
				}
				else
				{
					if(nodeIndex == 0) //if it's called at the beginning of a node
					{
						currentNode = cursor.previous;
						currentIndex = currentNode.count - 1;
					}
					else //if it's not
					{
						currentNode = cursor;
						currentIndex = nodeIndex - 1;
						position--;
					}
				}
			}
			
			removeMerge(currentNode, currentIndex); //actually removes the element
			direction = NONE;
			size--;
			
			if(currentIndex == -1 || currentNode == null)  //if method failed
			{
				throw new NullPointerException("Something when wrong with iter.remove()");
			}
			
			if(currentIndex == currentNode.count)  //if the index needs to be moved to the next node
			{
				cursor = currentNode.next;
				nodeIndex = 0;
			}
			else  //updates variables
			{
				cursor = currentNode;
				nodeIndex = currentIndex;
			}
		}
		
		/**
		 * Helper method for remove that triggers if only 1 element in list
		 */
		private void removeOnlyOneElement()
		{
			head.next = tail;
			tail.previous = head;
			cursor = null;
			nodeIndex--;
			cursor = tail;
			direction = NONE;
			size--;
		}
		
		/**
		 * Helper method for the iter.remove() method, this actually removes 
		 * the element and shifts/merges the data.
		 * 
		 * @param removeFrom: the node to remove from
		 * @param index: the index of the element to remove from
		 */
		private void removeMerge(Node removeFrom, int index) //helper method for remove(), helps the merge process
		{
			for(int i = index; i < nodeSize - 1; i++)  //shifts all elements back
			{
				removeFrom.data[i] = cursor.data[i + 1];
			}
			removeFrom.data[cursor.count - 1] = null;  //A B C| now A B|
			removeFrom.count--;
			
			if(removeFrom == tail.previous && removeFrom.count == 0) //if it's the last node with only 1 element
			{
				unlink(removeFrom);
				removeFrom = tail;
			}
			else if(removeFrom == tail.previous && removeFrom.count > nodeSize/2) //if the node is the last node with more than half the elements
			{
				
			}
			else //then do merge
			{
				if(removeFrom.next != tail) //fails if next node is tail!
				{
					Node nextNode = removeFrom.next;
					if(nextNode.count > nodeSize/2)  //mini-merge part
					{
						removeFrom.data[removeFrom.count] = nextNode.data[0];  //move next node's first element to remove node
						removeFrom.count++;
						for(int i = 0; i < nextNode.count - 1; i++)  //shift all the elements in next node
						{
							nextNode.data[i] = nextNode.data[i + 1];
						}
						nextNode.data[nextNode.count - 1] = null;
						nextNode.count--;
					}
					else if(removeFrom.count <= nodeSize/2)  //big merge only if it can fit the elements
					{
						for(int i = 0; i < nextNode.count; i++)  //shifts all elements into remove node
						{
							removeFrom.data[removeFrom.count + i] = nextNode.data[i];
						}
						removeFrom.count = removeFrom.count + nextNode.count;  //deletes next node
						unlink(nextNode);
					}
				}
			}
		}
		
		/**
		 * Returns if the list has a previous element, either goes to
		 * the previous node or previous element in the array.
		 * 
		 * @return returns a true or false based on the list having a previous element
		 */
		@Override
		public boolean hasPrevious() 
		{
			if(size == 0)   //this was implemented when the list got removed of all elements
			{
				return false;
			}
			
			if(cursor == head)
			{
				return false;
			}
			
			if (nodeIndex > 0 && cursor.data[nodeIndex - 1] != null) //checks if there's a previous element in the node 
				                                                     //array 
			{
		        return true;
		    }
			
			Node checkBeforeCursor = cursor.previous;
		    while (checkBeforeCursor != head)      //loops until no more nodes
		    {
		        for (int i = nodeSize - 1; i >= 0; i--)        //loops in the array in nodes
		        {
		            if (checkBeforeCursor.data[i] != null) 
		            {
		                return true;
		            }
		        }
		        checkBeforeCursor = checkBeforeCursor.previous;
		    }
		    return false;
		}
		
		/**
		 * Used to get the previous element in a list, either getting
		 * an element from the previous node or previous element in the array.
		 * 
		 * @return returns if the list has a previous element true or false.
		 */
		@Override
		public E previous() 
		{
			if(!hasPrevious())
			{
				throw new NoSuchElementException();
			}

			while(cursor != head)      //loops through all nodes
			{
				while(nodeIndex > 0)      //loops through node array
				{
					if(cursor.data[nodeIndex - 1] != null)  //if it finds an element
					{
						nodeIndex--;
						E info = cursor.data[nodeIndex];
						position--;
						direction = AHEAD;
						return info;
					}
					nodeIndex--;
				}
				nodeIndex = nodeSize;        //resets node index
				cursor = cursor.previous;
			}
			System.out.println("Previous method in StoutListIterator didn't work");
			return null; //shouldn't happen, just in case it fails
		}
		
		/**
		 * Gets the next index based on the position.
		 * 
		 * @return returns the position
		 */
		@Override
		public int nextIndex() 
		{
			return position;
		}
		
		/**
		 * Gets the previous index based on the position
		 * 
		 * @return returns the position
		 */
		@Override
		public int previousIndex() 
		{
			return position - 1;
		}
		
		/**
		 * Given a position in the list, changes the element at that position to a given element
		 * 
		 * @param e: the element you want to change the previous one to
		 */
		@Override
		public void set(E e) 
		{
			if(direction == NONE)
			{
				throw new IllegalStateException();
			}
			else if(direction == BEHIND) //next()
			{
				if(nodeIndex == 0)
				{
					cursor.previous.data[nodeSize - 1] = e;
				}
				else
				{
					cursor.data[nodeIndex - 1] = e;
				}
			}
			else if(direction == AHEAD) //previous()
			{
				cursor.data[nodeIndex] = e;
			}
		}
		
		/**
		 * This methods adds to the left of cursor, shifting elements if needed.
		 * 
		 * @param e: the element you want to add
		 */
		@Override
		public void add(E e)
		{
			if(e == null)
			{
				throw new NullPointerException("Inserted element is null");
			}
			if(size == 0)  //if list is empty, create a new Node
			{
				Node newNode = new Node();
				newNode.addItem(e);
				head.next = newNode;
				newNode.previous = head;  //updates head and tail
				newNode.next = tail;
				tail.previous = newNode;
				cursor = newNode;
				nodeIndex = 1;
				position++;
			}
			else
			{
				NodeInfo nodeInfo = findNodeInfo(position);  //finds the position of the node and offset
				Node currentNode = nodeInfo.node; //improves readability
				int offset = nodeInfo.offset;     //^
				
				NodeInfo nI = StoutList.this.add(currentNode, offset, e);  //adds it to the list
				cursor = nI.node;               //updates variables
				nodeIndex = nI.offset + 1;      //^
				position++;                     //^
			}
			size++;
			direction = NONE;
		}
	}


	/**
	 * Sorts an array using the insertion sort algorithm in the non-decreasing order. 
	 * 
	 * @param arr   array storing elements from the list 
	 * @param comp  comparator used in sorting 
	 */
	private void insertionSort(E[] arr, Comparator<? super E> comp)
	{
		for(int i = 1; i < arr.length; i++)
		{
			int j = i - 1;
			E min = arr[i];
			while(j >= 0 && comp.compare(arr[j], min) > 0)
			{
				arr[j + 1] = arr[j];
				j--;
			}
			arr[j + 1] = min;
		}
	}

	/**
	 * Sorts an array using the bubble sort algorithm in non-increasing order.
	 *  
	 * @param arr  array holding elements from the list
	 */
	private void bubbleSort(E[] arr)
	{
		boolean swapped = true;
		int n = arr.length;
		while(swapped)    //if no elements are swapped, 
		{
			swapped = false;
			for(int i = 1; i < n; i++)
			{
				if(arr[i - 1].compareTo(arr[i]) < 0)
				{
					E temp = arr[i - 1];
					arr[i - 1] = arr[i];
					arr[i] = temp;
					swapped = true;
				}
			}
		}
		n--;  //stops after last element sorted
	}
	
	/**
	 * Helper method that links a new node after a given node.
	 * 
	 * @param curNode: the node you want to add after
	 * @param newNode: the node you want to insert
	 */
	private void link(Node curNode, Node newNode) //links the node after cursor
	{
		if(head.next == tail) //do I need this
		{
			throw new IllegalStateException();
		}
		newNode.previous = curNode;
		newNode.next = curNode.next;
		curNode.next.previous = newNode;
		curNode.next = newNode;
	}
	
	/**
	 * Helper method that unlinks a node from the list.
	 * 
	 * @param current: unlinks the current node
	 */
	private void unlink(Node current)
	{
		if(head.next == tail)
		{
			throw new IllegalStateException();
		}
		current.previous.next = current.next;
		current.next.previous = current.previous;
	}
	
}