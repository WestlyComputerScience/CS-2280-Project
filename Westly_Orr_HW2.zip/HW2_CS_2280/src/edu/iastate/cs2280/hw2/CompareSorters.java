package edu.iastate.cs2280.hw2;

import java.io.FileNotFoundException;
import java.util.Scanner; 
import java.util.Random; 

/**
 * This class executes four sorting algorithms: selection sort, insertion sort, mergesort, and
 * quicksort, over randomly generated integers as well integers from a file input. It compares the 
 * execution times of these algorithms on the same input. 
 *  
 * @author Westly Orr
 * @date 10/7/2024
 * 
 */

public class CompareSorters 
{
	/**
	 * Repeatedly take integer sequences either randomly generated or read from files. 
	 * Use them as coordinates to construct points.  Scan these points with respect to their 
	 * median coordinate point four times, each time using a different sorting algorithm.  
	 * 
	 * @param args: string of arguments to be passed through
	 * @throws FileNotFoundException if file isn't found
	 **/
	public static void main(String[] args) throws FileNotFoundException
	{
		PointScanner[] scanners = new PointScanner[4]; 

		int end = 0;
		int trialCount = 0;
		Scanner s = new Scanner(System.in);
		while(end != 3)
		{
			System.out.println("keys: 1 (random integers) 2 (file input) 3(exit)");
			end = s.nextInt();
			if(end == 1)
			{
				trialCount++;
				Random gen = new Random();
				System.out.println("Enter number of random points: ");
				int numPoints = s.nextInt();
				Point[] points = CompareSorters.generateRandomPoints(numPoints, gen);
				
				scanners[0] = new PointScanner(points, Algorithm.SelectionSort);
				scanners[1] = new PointScanner(points, Algorithm.InsertionSort);
				scanners[2] = new PointScanner(points, Algorithm.MergeSort);
				scanners[3] = new PointScanner(points, Algorithm.QuickSort);

				for(int i = 0; i < scanners.length; i++)
				{
					scanners[i].scan();
				}
				
				CompareSorters.printTrial(trialCount, scanners);
			}
			else if(end == 2)
			{
				try
				{
					trialCount++;
					System.out.println("File name: ");
					String f = "";
					while(f.equals(""))
					{
						f = s.nextLine();
					}

					scanners[0] = new PointScanner(f, Algorithm.SelectionSort);
					scanners[1] = new PointScanner(f, Algorithm.InsertionSort);
					scanners[2] = new PointScanner(f, Algorithm.MergeSort);
					scanners[3] = new PointScanner(f, Algorithm.QuickSort);

					for(int i = 0; i < scanners.length; i++)
					{
						scanners[i].scan();
					}
					CompareSorters.printTrial(trialCount, scanners);
				}
				catch(FileNotFoundException e)
				{
					System.out.println("Error: File not found");
				}
			}
			else if(end == 3)
			{
				//just terminates program
			}
			else
			{
				System.out.println("Please enter 1, 2, or 3!");
			}
		}
		s.close();
	}

	/**
	 * prints the stats for a trial
	 * 
	 * @param trialCount: used to indicate which trial number to display
	 * @param scanners: used to print the statistics line from each sort
	 */
	public static void printTrial(int trialCount, PointScanner[] scanners)
	{
		System.out.println("Trial count: " + trialCount);
		System.out.printf("%-15s %6s %12s%n", "Algorithm", "Size", "Time (ns)");
		System.out.printf("-----------------------------------%n");
		System.out.printf("%s%n", scanners[0].stats());
		System.out.printf("%s%n", scanners[1].stats());
		System.out.printf("%s%n", scanners[2].stats());
		System.out.printf("%s%n", scanners[3].stats());
		System.out.printf("-----------------------------------%n");
	}


	/**
	 * This method generates a given number of random points.
	 * The coordinates of these points are pseudo-random numbers within the range 
	 * [-50,50] � [-50,50].
	 * 
	 * @param numPts  	number of points
	 * @param rand      Random object to allow seeding of the random number generator
	 * @throws IllegalArgumentException if numPts < 1
	 * 
	 * @return returns the point array it created
	 */
	private static Point[] generateRandomPoints(int numPts, Random rand) throws IllegalArgumentException
	{ 
		Point[] points;
		try
		{
			points = new Point[numPts];
			for(int i = 0; i < numPts; i++)
			{
				int x = rand.nextInt(101) - 50;
				int y = rand.nextInt(101) - 50;
				Point p = new Point(x, y);
				points[i] = p;
			}
			return points;
		}
		catch(IllegalArgumentException e)
		{
			System.out.println("Error: generateRandomPoints array.length < 1");
		}
		return null;
	}
}
