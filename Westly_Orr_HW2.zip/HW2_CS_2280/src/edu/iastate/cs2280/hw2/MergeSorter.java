package edu.iastate.cs2280.hw2;

import java.io.FileNotFoundException;
import java.lang.NumberFormatException; 
import java.lang.IllegalArgumentException; 
import java.util.InputMismatchException;

/**
 * 
 * This class implements the mergesort algorithm.   
 *
 * @author Westly Orr
 * @date 10/7/2024
 */

public class MergeSorter extends AbstractSorter
{

	/** 
	 * Constructor takes an array of points.  It invokes the superclass constructor, and also 
	 * set the instance variables algorithm in the superclass.
	 *  
	 * @param pts: input array of integers
	 */
	public MergeSorter(Point[] pts) 
	{
		super(pts);
		algorithm = "mergesort";
	}


	/**
	 * Perform mergesort on the array points[] of the parent class AbstractSorter. 
	 * 
	 */
	@Override 
	public void sort()
	{
		sortTime = 0;
		long startTime = System.nanoTime();

		mergeSortRec(points);

		long endTime = System.nanoTime();
		sortTime = endTime - startTime;
	}


	/**
	 * This is a recursive method that carries out mergesort on an array pts[] of points
	 * 
	 * @param pts	point array 
	 */
	private void mergeSortRec(Point[] pts)
	{
		int h = pts.length;
		if(h <= 1)
		{
			return;
		}

		int m = h/2;
		Point[] b = createArr(pts, 0, m);
		Point[] c = createArr(pts, m, h);
		mergeSortRec(b);
		mergeSortRec(c);
		Point[] merged = merge(b, c);

		//copies merged array back into points!
		//works because values reassigned every recursive call until correct!
		for (int i = 0; i < h; i++) 
		{
			pts[i] = merged[i];
		}
	}

	/**
	 * This is used to create a partial array from the given array
	 * 
	 * @param a: array we're taking points from
	 * @param l: low index we're creating at
	 * @param h: high index we're finishing at
	 * @return returns created array
	 */
	private Point[] createArr(Point[] a, int l, int h)
	{
		Point[] b = new Point[h - l];
		for(int i = l; i < h; i++)
		{
			b[i - l] = a[i];
		}
		return b;
	}

	/**
	 * merges 2 arrays together
	 * 
	 * @param b: array 1 we're merging
	 * @param c: array 2 we're merging
	 * @return returns merged array
	 */
	private Point[] merge(Point[] b, Point[] c)
	{
		int p = b.length;
		int q = c.length;
		Point[] d = new Point[p + q];
		int i = 0;
		int j = 0;
		int k = 0;
		while(i < p && j < q)
		{
			if(pointComparator.compare(b[i], c[j]) == -1)
			{
				d[k] = b[i];
				i++;
				k++;
			}
			else
			{
				d[k] = c[j];
				j++;
				k++;
			}
		}
		while(j < q)
		{
			d[k] = c[j];
			j++;
			k++;
		}
		while(i < p)
		{
			d[k] = b[i];
			i++;
			k++;
		}
		return d;
	}
}
