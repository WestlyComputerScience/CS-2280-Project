package edu.iastate.cs2280.hw2;

import java.io.FileNotFoundException;
import java.lang.NumberFormatException; 
import java.lang.IllegalArgumentException; 
import java.util.InputMismatchException;

/**
 * 
 * This class implements selection sort.   
 * 
 * @author Westly Orr
 * @date 10/7/2024
 *
 */

public class SelectionSorter extends AbstractSorter
{
	
	/**
	 * Constructor takes an array of points.  It invokes the superclass constructor, and also 
	 * set the instance variables algorithm in the superclass.
	 *  
	 * @param pts: input array of integers
	 */
	public SelectionSorter(Point[] pts)  
	{
		super(pts);
		algorithm = "selection sort";
	}	


	/** 
	 * Apply selection sort on the array points[] of the parent class AbstractSorter.  
	 * 
	 */
	@Override 
	public void sort()
	{
		sortTime = 0;
		long startTime = System.nanoTime();
		
		for(int i = 0; i < points.length - 1; i++)
		{
			int min = i;
			for(int j = i + 1; j < points.length; j++)
			{
				if(pointComparator.compare(points[min], points[j]) == 1)
				{
					min = j;
				}
			}
			swap(i, min);
			
		}
		
		long endTime = System.nanoTime();
		sortTime = endTime - startTime;
	}	
}
