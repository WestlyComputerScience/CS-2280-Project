 package edu.iastate.cs2280.hw2;

/**
 *  This class is used to create the object for coordinate points on a grid
 *  
 * @author Westly Orr
 * @date 10/7/2024
 */

public class Point implements Comparable<Point>
{
	private int x; //x coordinate
	private int y; //y coordinate
	
	public static boolean xORy;  // compare x coordinates if xORy == true and y coordinates otherwise 
	                             // To set its value, use Point.xORy = true or false. 
	/*
	 * default constructor
	 */
	public Point()
	{
		x = 0;
		y = 0;
	}
	
	/**
	 * constructor that takes coordinates in and outputs a coordinate pair object
	 * 
	 * @param x: x coordinate
	 * @param y: y coordinate
	 */
	public Point(int x, int y)
	{
		this.x = x;  
		this.y = y;   
	}
	
	/**
	 * Used to copy a pair of points
	 * 
	 * @param p: point object it's copying from
	 */
	public Point(Point p) // copy constructor
	{
		x = p.getX();
		y = p.getY();
	}

	/**
	 * Accessor method for x-coordinate
	 * 
	 * @return returns the x-coordinate
	 */
	public int getX()   
	{
		return x;
	}
	
	/**
	 * Accessor method for y-coordinate
	 * 
	 * @return returns the y-coordinate
	 */
	public int getY()
	{
		return y;
	}
	
	/** 
	 * Sets the value of the static instance variable xORy that dictates whether or not to 
	 * compare the x or y value. 
	 * 
	 * @param xORy: boolean value indicating whether to compare x or y
	 */
	public static void setXorY(boolean xORy)
	{
		Point.xORy = xORy;
	}
	
	/**
	 * Used to test if point objects equal each other
	 * 
	 * @param obj: intakes a point object to compare
	 * @return returns true or false if they are equal
	 */
	@Override
	public boolean equals(Object obj)
	{
		if (obj == null || obj.getClass() != this.getClass())
		{
			return false;
		}
    
		Point other = (Point) obj;
		return x == other.x && y == other.y;   
	}

	/**
	 * Compare this point with a second point q depending on the value of the static variable xORy 
	 * 
	 * @param 	q : compares a this point object to a q point object
	 * @return  -1  if (xORy == true && (this.x < q.x || (this.x == q.x && this.y < q.y))) 
	 *                || (xORy == false && (this.y < q.y || (this.y == q.y && this.x < q.x)))
	 * 		    0   if this.x == q.x && this.y == q.y)  
	 * 			1	otherwise 
	 */
	public int compareTo(Point q)
	{
		if(this.x == q.x && this.y == q.y)
		{
			return 0;
		}
		else if (xORy == true && (this.x < q.x || (this.x == q.x && this.y < q.y))
			 || (xORy == false && (this.y < q.y || (this.y == q.y && this.x < q.x))))
		{
			return -1;
		}
		return 1;
		
	}
	
	
	/**
	 * Output a point in the standard form (x, y). 
	 * 
	 * @return returns the string in standard form (x, y)
	 */
	@Override
    public String toString() 
	{
		String s = "(" + this.x + ", " + this.y + ")";
		return s;
	}
}
