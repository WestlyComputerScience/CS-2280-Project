package edu.iastate.cs2280.hw2;

import java.io.FileNotFoundException;
import java.lang.NumberFormatException; 
import java.lang.IllegalArgumentException; 
import java.util.InputMismatchException;

/**
 * 
 * This class implements insertion sort.   
 *
 * @author Westly Orr
 * @date 10/7/2024
 */

public class InsertionSorter extends AbstractSorter 
{
	/**
	 * Constructor takes an array of points.  It invokes the superclass constructor, and also 
	 * set the instance variables algorithm in the superclass.
	 * 
	 * @param pts: input array of points
	 */
	public InsertionSorter(Point[] pts) 
	{
		super(pts);
		algorithm = "insertion sort";
	}	


	/** 
	 * Perform insertion sort on the array points[] of the parent class AbstractSorter.  
	 */
	@Override 
	public void sort()
	{
		sortTime = 0;
		long startTime = System.nanoTime();
		
		for(int i = 1; i < points.length; i++)
		{
			Point min = points[i];
			int j = i - 1;
			while(j >= 0)
			{
				if (pointComparator.compare(min, points[j]) == -1)
				{
					points[j+1] = points[j];
					j--;
				}
				else
				{
					break;
				}
			}
			points[j+1] = min;
		}
		
		long endTime = System.nanoTime();
		sortTime = endTime - startTime;
	}
}
