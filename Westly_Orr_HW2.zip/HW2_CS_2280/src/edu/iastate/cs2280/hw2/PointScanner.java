package edu.iastate.cs2280.hw2;

import java.io.File;

/**
 * 
 * @author 
 *
 */

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.InputMismatchException;
import java.util.Scanner;


/**
 * 
 * This class sorts all the points in an array of 2D points to determine a reference point whose x and y 
 * coordinates are respectively the medians of the x and y coordinates of the original points. 
 * 
 * It records the employed sorting algorithm as well as the sorting time for comparison. 
 * 
 * @author Westly Orr
 * @date 10/7/2024
 *
 */
public class PointScanner  
{
	private Point[] points; //array of point objects on a coordinate grid

	private Point medianCoordinatePoint;  // point whose x and y coordinates are respectively the medians of 
	// the x coordinates and y coordinates of those points in the array points[].
	
	private Algorithm sortingAlgorithm;    //which sorting algorithm is being used


	protected long scanTime; 	       // execution time in nanoseconds. 

	/**
	 * This constructor accepts an array of points and one of the four sorting algorithms as input. Copy 
	 * the points into the array points[].
	 * 
	 * @param  pts: input array of points 
	 * @param  algo: which sort is being used
	 * @throws IllegalArgumentException if pts == null or pts.length == 0.
	 */
	public PointScanner(Point[] pts, Algorithm algo) throws IllegalArgumentException
	{
		try
		{
			if(pts == null || pts.length == 0)
			{
				throw new IllegalArgumentException();
			}

			points = new Point[pts.length];
			for(int i = 0; i < pts.length; i++)
			{
				points[i] = pts[i];
			}

			sortingAlgorithm = algo;
		}
		catch (IllegalArgumentException e)
		{
			System.out.print("Error: inputed array is null or length of 0!");
		}
	}


	/**
	 * This constructor reads points from a file and puts it into an array
	 * 
	 * @param  inputFileName: file you want to use
	 * @param  algo: which sort is being used
	 * @throws FileNotFoundException: if file isn't found
	 * @throws InputMismatchException: if the input file contains an odd number of integers
	 */
	protected PointScanner(String inputFileName, Algorithm algo) throws FileNotFoundException, InputMismatchException
	{
		try
		{
			File f = new File(inputFileName);
			int x = -70;
			int y = -70;
			int count = 0;
			Scanner fileScan = new Scanner(f);
			while (fileScan.hasNextInt())
			{
				fileScan.nextInt();
				count++;
			}

			if(count % 2 != 0)
			{
				fileScan.close();
				throw new InputMismatchException();
			}

			points = new Point[count/2];
			//resetting scanner
			fileScan.close();
			fileScan = new Scanner(f);

			count = 0;
			int k = 0;
			while (fileScan.hasNextInt())
			{
				if(count % 2 == 0)
				{
					x = fileScan.nextInt();
					count++;
				}
				else
				{
					y = fileScan.nextInt();
					count++;
				}
				if((x != -70) && (y != -70))
				{
					Point p = new Point(x, y);
					points[k] = p;
					k++;
					x = -70;
					y = -70;
				}
			}

			sortingAlgorithm = algo;
			fileScan.close();
		}
		catch(InputMismatchException e)
		{
			System.out.println("Error: input file contains odd number of integers");
		}
	}

	/**
	 * picks which sorting algorithm to use
	 * 
	 * @param algo: which sorting algorithm to use
	 * @return returns an AbstractSorter object created with a new sorter
	 */
	public AbstractSorter algoSort(Algorithm algo)
	{
		Algorithm s = Algorithm.SelectionSort;
		Algorithm i = Algorithm.InsertionSort;
		Algorithm m = Algorithm.MergeSort;

		AbstractSorter aSorter;

		if(sortingAlgorithm == s)
		{
			aSorter = new SelectionSorter(points);
		}
		else if(sortingAlgorithm == i)
		{
			aSorter = new InsertionSorter(points);
		}
		else if(sortingAlgorithm == m)
		{
			aSorter = new MergeSorter(points);
		}
		else
		{
			aSorter = new QuickSorter(points);
		}

		return aSorter;
	}


	/**
	 * Based on the value of sortingAlgorithm, creates an object of SelectionSorter, InsertionSorter, MergeSorter,
	 * or QuickSorter to carry out sorting.
	 * 
	 */
	public void scan()
	{
		AbstractSorter aSorter; 
		aSorter = algoSort(sortingAlgorithm);
		
		
		aSorter.setComparator(0);
		aSorter.sort();
		scanTime = scanTime + aSorter.getTime();
		Point p1 = aSorter.getMedian();

		aSorter.setComparator(1);
		aSorter.sort();
		scanTime = scanTime + aSorter.getTime();
		Point p2 = aSorter.getMedian();

		//used in combination with writeMCPToFile to test if sort method works
		//aSorter.getPoints(points);

		medianCoordinatePoint = new Point(p1.getX(), p2.getY());
	}


	/**
	 * Outputs performance statistics
	 * 
	 * @return returns the string line for the statistics gathered
	 */
	public String stats()
	{
		return String.format("%-15s %6d %12d", sortingAlgorithm, points.length, scanTime);
	}


	/**
	 * Outputs the median coordinate point when using a pointScanner object
	 * 
	 * @return returns median coordinate point string
	 */
	@Override
	public String toString()
	{
		String s = "MCP: " + medianCoordinatePoint;
		return s;
	}


	/**
	 *  
	 * This method, called after scanning, writes point data into a file by outputFileName.
	 * 
	 * @throws FileNotFoundException if file not found
	 */
	public void writeMCPToFile() throws FileNotFoundException
	{
		try
		{
			File output = new File("outputFile.txt");
			PrintWriter writer = new PrintWriter(output);
			for(int i = 0; i < points.length; i++)
			{
				writer.println(points[i]);
			}
			writer.close();
		}
		catch(FileNotFoundException e)
		{
			System.out.println("Couldn't find output file");
		}
	}	

}
