package edu.iastate.cs2280.hw2;

import java.util.Comparator;
import java.io.FileNotFoundException;
import java.lang.IllegalArgumentException; 
import java.util.InputMismatchException;

/**
 * 
 * This abstract class is extended by SelectionSort, InsertionSort, MergeSort, and QuickSort.
 * It stores the input (later the sorted) sequence. 
 *
 * @author Westly Orr
 * @date 10/7/2024
 * 
 */

public abstract class AbstractSorter
{
	protected static long sortTime; //used to measure sort time

	protected Point[] points;    // array of points operated on by a sorting algorithm. 
	// stores ordered points after a call to sort(). 

	protected String algorithm = null; // "selection sort", "insertion sort", "mergesort", or
	// "quicksort". Initialized by a subclass constructor.

	protected Comparator<Point> pointComparator = null;  //used to create a point comparator to compare point objects

	/**
	 * This constructor accepts an array of points as input. Copy the points into the array points[]. 
	 * 
	 * @param  pts: input array of points 
	 * @throws IllegalArgumentException if pts == null or pts.length == 0.
	 */
	
	protected AbstractSorter()
	{
		// No implementation needed. Provides a default super constructor to subclasses. 
		// Removable after implementing SelectionSorter, InsertionSorter, MergeSorter, and QuickSorter.
	}
	
	
	protected AbstractSorter(Point[] pts) throws IllegalArgumentException
	{
		try
		{
			if(pts == null || pts.length == 0)
			{
				throw new IllegalArgumentException();
			}
			points = new Point[pts.length];
			for(int i = 0; i < pts.length; i++)
			{
				points[i] = pts[i];
			}
		}
		catch (IllegalArgumentException e)
		{
			System.out.print("Incorrect Input: Try inputing an array with point objects inside");
		}
	}


	/**
	 * Generates a comparator on the fly that compares by x-coordinate if order == 0, 
	 * by y-coordinate if order == 1. 
	 * Assigns the comparator to the variable pointComparator. 
	 * 
	 * @param order: 0   by x-coordinate 
	 * 				 1   by y-coordinate
	 * 			    
	 * @throws IllegalArgumentException if order is less than 0 or greater than 1
	 *        
	 */
	public void setComparator(int order) throws IllegalArgumentException
	{
		try
		{
			if (order != 0 && order != 1) 
			{
				throw new IllegalArgumentException("Order must be 0 or 1");
			}

			pointComparator = new Comparator<Point>()
			{
				@Override
				public int compare(Point p1, Point p2)
				{
					if (order == 0) 
					{
						Point.setXorY(true);
						return p1.compareTo(p2);
					} 
					else 
					{
						Point.setXorY(false);
						return p1.compareTo(p2);
					}
				}
			};
		}
		
		catch(IllegalArgumentException e)
		{
			System.out.println("Error: Incorrect order arguement for setComparator");
		}
	}


	/**
	 * Use the created pointComparator to conduct sorting.  
	 * 
	 * Should be protected. Made public for testing. 
	 */
	public abstract void sort(); 


	/**
	 * Obtain the point in the array points[] that has median index 
	 * 
	 * @return	median point 
	 */
	public Point getMedian()
	{
		return points[points.length/2]; 
	}


	/**
	 * Copys the array points[] onto the array pts[]. 
	 * 
	 * @param pts: input array of points
	 */
	public void getPoints(Point[] pts)
	{
		for (int i = 0; i < pts.length; i++)
		{
			pts[i] = points[i];
		}
	}


	/**
	 * Swaps the two elements indexed at i and j respectively in the array points[]. 
	 * 
	 * @param i: index of point object
	 * @param j: index of point object
	 */
	protected void swap(int i, int j)
	{
		//double check this later!
		Point temp = points[i];
		points[i] = points[j];
		points[j] = temp;
	}	

	/**
	 * Gets the amount of time it takes to sort when subclasses sort
	 * 
	 * @return returns the sorting time
	 */
	public long getTime()
	{
		return sortTime;
	}
}
