package edu.iastate.cs2280.hw2;

import java.io.FileNotFoundException;
import java.lang.NumberFormatException; 
import java.lang.IllegalArgumentException; 
import java.util.InputMismatchException;

/**
 * 
 * This class implements the version of the quicksort algorithm presented in the lecture. 
 *   
 * @author Westly Orr
 * @date 10/7/2024
 */

public class QuickSorter extends AbstractSorter
{

	/** 
	 * Constructor takes an array of points.  It invokes the superclass constructor, and also 
	 * set the instance variables algorithm in the superclass.
	 *   
	 * @param pts: input array of integers
	 */
	public QuickSorter(Point[] pts)
	{
		super(pts);
		algorithm = "quicksort";
	}


	/**
	 * Carry out quicksort on the array points[] of the AbstractSorter class.  
	 * 
	 */
	@Override 
	public void sort()
	{
		sortTime = 0;
		long startTime = System.nanoTime();
		
		quickSortRec(0, points.length-1);
		
		long endTime = System.nanoTime();
		sortTime = endTime - startTime;
	}


	/**
	 * Operates on the subarray of points[] with indices between first and last. 
	 * 
	 * @param first: starting index of the subarray
	 * @param last: ending index of the subarray
	 */
	private void quickSortRec(int first, int last)
	{
		if(first >= last)
		{
			return;
		}

		int p = partition(first, last);
		quickSortRec(first, p-1);
		quickSortRec(p+1, last);
	}


	/**
	 * Operates on the subarray of points[] with indices between first and last.
	 * 
	 * @param first: starting index of the subarray
	 * @param last: ending index of the subarray
	 * @return returns the position of the pivot in the array
	 */
	private int partition(int first, int last)
	{
		Point pivot = points[last];
		int i = first - 1;

		for(int j = first; j < last; j++)
		{
			if(pointComparator.compare(points[j], pivot) <= 0)
			{
				i++;
				swap(i, j);
			}
		}
		swap(i+1, last);
		return i+1;
	}	

}
